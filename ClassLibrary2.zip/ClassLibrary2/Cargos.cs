﻿namespace ClassLibrary2
{
    public class Cargos
    {
        public int idCargo { get; set; }
        public string codCargo { get; set; }
        public string cargo { get; set; }
        public decimal? valor { get; set; }
        public string codUni { get; set; }
        public int? recursot { get; set; }
    }
}
